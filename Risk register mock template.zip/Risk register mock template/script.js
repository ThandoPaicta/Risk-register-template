function showRiskRegister() {
    document.getElementById("riskRegisterPage").style.display = "block";
    document.getElementById("addRiskPage").style.display = "none";
    document.getElementById("statusPage").style.display = "none";
}

function showAddRiskForm() {
    document.getElementById("riskRegisterPage").style.display = "none";
    document.getElementById("addRiskPage").style.display = "block";
    document.getElementById("statusPage").style.display = "none";
}

function showStatusPage() {
    document.getElementById("riskRegisterPage").style.display = "none";
    document.getElementById("addRiskPage").style.display = "none";
    document.getElementById("statusPage").style.display = "block";
}

function exportRiskRegisterReports() {
    const csvContent = "data:text/csv;charset=utf-8," + encodeURIComponent("Project,Risk Level,Description\nProject 1,High,Description of High Risk 1\nProject 2,High,Description of High Risk 2\nProject 3,Medium,Description of Medium Risk 1\nProject 4,Medium,Description of Medium Risk 2\nProject 5,Low,Description of Low Risk 1\nProject 6,Low,Description of Low Risk 2");

    const link = document.createElement("a");
    link.setAttribute("href", csvContent);
    link.setAttribute("download", "risk_register_reports.csv");
    link.click();
}

window.addEventListener("DOMContentLoaded", function() {
    const riskData = [
        { project: "Project 1", riskLevel: "high", description: "Description of High Risk 1" },
        { project: "Project 2", riskLevel: "high", description: "Description of High Risk 2" },
        { project: "Project 3", riskLevel: "medium", description: "Description of Medium Risk 1" },
        { project: "Project 4", riskLevel: "medium", description: "Description of Medium Risk 2" },
        { project: "Project 5", riskLevel: "low", description: "Description of Low Risk 1" },
        { project: "Project 6", riskLevel: "low", description: "Description of Low Risk 2" }
    ];

    const riskRegisterTable = document.getElementById("riskRegisterTable");
    const statusTable = document.getElementById("statusTable");

    riskData.forEach(function(data) {
        const riskRegisterRow = document.createElement("tr");
        riskRegisterRow.innerHTML = `
            <td>${data.project}</td>
            <td>${data.riskLevel}</td>
            <td>${data.description}</td>
        `;
        riskRegisterTable.querySelector("tbody").appendChild(riskRegisterRow);

        const statusRow = document.createElement("tr");
        statusRow.innerHTML = `
            <td>${data.project}</td>
            <td>${data.riskLevel}</td>
            <td>${data.description}</td>
        `;
        statusTable.querySelector("tbody").appendChild(statusRow);

        const cardColumn = document.querySelector(`.${data.riskLevel} .card-column`);
        const card = document.createElement("div");
        card.className = "card";
        card.textContent = data.description;
        cardColumn.appendChild(card);
    });
});
